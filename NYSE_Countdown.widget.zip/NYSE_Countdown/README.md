# New York Stock Exchange countdown widget

## A Minimalistic and Beautiful NYSE Countdown Widget for macOS

## Created by Petr Smetala

### Works with Ubersight app
### Simple JSX file - Hence it is fully customizable :)
